package BookingSystem;

public class GuestHouseBooking {
	
	//Session_3_Inheritance_Interfaces_HandsOn
	public interface GuestHousebooking {
	     public int roomSelection();
	     public void roomAvalibility();
	     public void checkInputDate();
	     public void selection();
	}

}
